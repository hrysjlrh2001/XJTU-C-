﻿namespace Week_9_q2
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.c1 = new System.Windows.Forms.TextBox();
            this.c3 = new System.Windows.Forms.TextBox();
            this.c2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.k_p = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // c1
            // 
            this.c1.BackColor = System.Drawing.Color.Red;
            this.c1.HideSelection = false;
            this.c1.Location = new System.Drawing.Point(135, 95);
            this.c1.Multiline = true;
            this.c1.Name = "c1";
            this.c1.ReadOnly = true;
            this.c1.Size = new System.Drawing.Size(88, 82);
            this.c1.TabIndex = 0;
            this.c1.TextChanged += new System.EventHandler(this.c1_TextChanged);
            this.c1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.c1_KeyDown);
            this.c1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.c1_KeyPress);
            // 
            // c3
            // 
            this.c3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.c3.Location = new System.Drawing.Point(551, 95);
            this.c3.Multiline = true;
            this.c3.Name = "c3";
            this.c3.ReadOnly = true;
            this.c3.Size = new System.Drawing.Size(88, 82);
            this.c3.TabIndex = 1;
            // 
            // c2
            // 
            this.c2.BackColor = System.Drawing.Color.Yellow;
            this.c2.Location = new System.Drawing.Point(343, 95);
            this.c2.Multiline = true;
            this.c2.Name = "c2";
            this.c2.ReadOnly = true;
            this.c2.Size = new System.Drawing.Size(88, 82);
            this.c2.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(273, 268);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "此时输入的键是：";
            // 
            // k_p
            // 
            this.k_p.Location = new System.Drawing.Point(277, 360);
            this.k_p.Name = "k_p";
            this.k_p.ReadOnly = true;
            this.k_p.Size = new System.Drawing.Size(191, 25);
            this.k_p.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.k_p);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.c2);
            this.Controls.Add(this.c3);
            this.Controls.Add(this.c1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox c1;
        private System.Windows.Forms.TextBox c3;
        private System.Windows.Forms.TextBox c2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox k_p;
    }
}

