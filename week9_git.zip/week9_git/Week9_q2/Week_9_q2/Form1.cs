﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_9_q2
{
    public partial class Form1 : Form
    {
        private string k_d="Q";
        private int i = 0;
        private Color c_r = Color.Red;
        private Color c_g = Color.Green;
        private Color c_y = Color.Yellow;
        private Color c_gy = Color.Gray;
        private void c_change(int i)
        {
            if (i % 3 == 0)
            {
                c1.BackColor = c_r;
                c2.BackColor = c_gy;
                c3.BackColor = c_gy;
            }
            else if (i % 3 == 1)
            {
                c1.BackColor = c_gy;
                c2.BackColor = c_y;
                c3.BackColor = c_gy;
            }
            else
            {
                c1.BackColor = c_gy;
                c2.BackColor = c_gy;
                c3.BackColor = c_g;
            }
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            i += 1;
            c_change(i);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void c1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void c1_KeyPress(object sender, KeyPressEventArgs e)
        {
        }

        private void c1_KeyDown(object sender, KeyEventArgs e)
        {
            k_d = Convert.ToString(e.KeyCode);
            k_p.Text = k_d;
            if (k_d == "S")
            {
                timer1.Enabled = true;
            }
            else if (k_d == "E")
            {
                timer1.Enabled = false;
            }
        }
    }
}
