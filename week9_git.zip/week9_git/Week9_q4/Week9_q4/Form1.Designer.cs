﻿namespace Week9_q4
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.username = new System.Windows.Forms.TextBox();
            this.password = new System.Windows.Forms.TextBox();
            this.emial = new System.Windows.Forms.TextBox();
            this.password_1 = new System.Windows.Forms.TextBox();
            this.age = new System.Windows.Forms.NumericUpDown();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.female = new System.Windows.Forms.RadioButton();
            this.male = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.singing = new System.Windows.Forms.CheckBox();
            this.reading = new System.Windows.Forms.CheckBox();
            this.gaming = new System.Windows.Forms.CheckBox();
            this.music = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.age)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // username
            // 
            this.username.Location = new System.Drawing.Point(122, 86);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(87, 25);
            this.username.TabIndex = 0;
            this.username.TextChanged += new System.EventHandler(this.username_TextChanged);
            // 
            // password
            // 
            this.password.Location = new System.Drawing.Point(122, 153);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(87, 25);
            this.password.TabIndex = 1;
            // 
            // emial
            // 
            this.emial.Location = new System.Drawing.Point(485, 221);
            this.emial.Name = "emial";
            this.emial.Size = new System.Drawing.Size(87, 25);
            this.emial.TabIndex = 2;
            // 
            // password_1
            // 
            this.password_1.Location = new System.Drawing.Point(122, 221);
            this.password_1.Name = "password_1";
            this.password_1.Size = new System.Drawing.Size(87, 25);
            this.password_1.TabIndex = 3;
            // 
            // age
            // 
            this.age.Location = new System.Drawing.Point(485, 94);
            this.age.Name = "age";
            this.age.Size = new System.Drawing.Size(87, 25);
            this.age.TabIndex = 4;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.female);
            this.groupBox1.Controls.Add(this.male);
            this.groupBox1.Location = new System.Drawing.Point(485, 289);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(195, 77);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "性别";
            // 
            // female
            // 
            this.female.AutoSize = true;
            this.female.Location = new System.Drawing.Point(34, 52);
            this.female.Name = "female";
            this.female.Size = new System.Drawing.Size(43, 19);
            this.female.TabIndex = 14;
            this.female.TabStop = true;
            this.female.Text = "女";
            this.female.UseVisualStyleBackColor = true;
            // 
            // male
            // 
            this.male.AutoSize = true;
            this.male.Location = new System.Drawing.Point(34, 21);
            this.male.Name = "male";
            this.male.Size = new System.Drawing.Size(43, 19);
            this.male.TabIndex = 0;
            this.male.TabStop = true;
            this.male.Text = "男";
            this.male.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.singing);
            this.panel1.Controls.Add(this.reading);
            this.panel1.Controls.Add(this.gaming);
            this.panel1.Controls.Add(this.music);
            this.panel1.Location = new System.Drawing.Point(115, 289);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(224, 102);
            this.panel1.TabIndex = 6;
            // 
            // singing
            // 
            this.singing.AutoSize = true;
            this.singing.Location = new System.Drawing.Point(123, 14);
            this.singing.Name = "singing";
            this.singing.Size = new System.Drawing.Size(59, 19);
            this.singing.TabIndex = 14;
            this.singing.Text = "唱歌";
            this.singing.UseVisualStyleBackColor = true;
            // 
            // reading
            // 
            this.reading.AutoSize = true;
            this.reading.Location = new System.Drawing.Point(25, 58);
            this.reading.Name = "reading";
            this.reading.Size = new System.Drawing.Size(59, 19);
            this.reading.TabIndex = 15;
            this.reading.Text = "看书";
            this.reading.UseVisualStyleBackColor = true;
            this.reading.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // gaming
            // 
            this.gaming.AutoSize = true;
            this.gaming.Location = new System.Drawing.Point(122, 58);
            this.gaming.Name = "gaming";
            this.gaming.Size = new System.Drawing.Size(59, 19);
            this.gaming.TabIndex = 16;
            this.gaming.Text = "游戏";
            this.gaming.UseVisualStyleBackColor = true;
            // 
            // music
            // 
            this.music.AutoSize = true;
            this.music.Location = new System.Drawing.Point(25, 14);
            this.music.Name = "music";
            this.music.Size = new System.Drawing.Size(58, 23);
            this.music.TabIndex = 0;
            this.music.Text = "音乐";
            this.music.UseCompatibleTextRendering = true;
            this.music.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(495, 390);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 39);
            this.button1.TabIndex = 7;
            this.button1.Text = "提交";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(46, 96);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 15);
            this.label1.TabIndex = 8;
            this.label1.Text = "用户名";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(46, 163);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 15);
            this.label2.TabIndex = 9;
            this.label2.Text = "密码";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(46, 231);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 15);
            this.label3.TabIndex = 10;
            this.label3.Text = "确认密码";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(397, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 15);
            this.label4.TabIndex = 11;
            this.label4.Text = "年龄";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(46, 289);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 15);
            this.label6.TabIndex = 13;
            this.label6.Text = "label6";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(397, 231);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 15);
            this.label5.TabIndex = 12;
            this.label5.Text = "邮箱";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.age);
            this.Controls.Add(this.password_1);
            this.Controls.Add(this.emial);
            this.Controls.Add(this.password);
            this.Controls.Add(this.username);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.age)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox username;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.TextBox emial;
        private System.Windows.Forms.TextBox password_1;
        private System.Windows.Forms.NumericUpDown age;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton female;
        private System.Windows.Forms.RadioButton male;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox gaming;
        private System.Windows.Forms.CheckBox music;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox singing;
        private System.Windows.Forms.CheckBox reading;
    }
}

