﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week9_q4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }
        private bool vagri(char ori,string pan)
        {
            bool ipp = true;
            for(int i = 0; i < pan.Length; i++)
            {
                if (ori == pan[i])
                {
                    return false;
                }
            }
            return ipp;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string gender;
            string hobby = "";
            if (music.Checked == true)
            {
                hobby += "音乐";
            }
            if (singing.Checked == true)
            {
                hobby += "唱歌";
            }
            if (gaming.Checked == true)
            {
                hobby += "游戏 ";
            }
            if (reading.Checked == true)
            {
                hobby += "读书";
            }
            if (male.Checked == true)
            {
                female.Checked = false;
                gender = "男";
            }
            else
            {
                female.Checked = true;
                gender = "女";
            }
            if (password.Text != password_1.Text)
            {
                MessageBox.Show("密码不同！");
            }
            else if (vagri('@', emial.Text))
            {
                MessageBox.Show("邮箱不合法！");
            }
            else
            {
                string print = string.Format("注册成功！\n\t用户名为{0},年龄为{1}，性别为{2}，爱好有{3}", username.Text, age.Value, gender, hobby);
                MessageBox.Show(print);
            }
        }

        private void username_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
