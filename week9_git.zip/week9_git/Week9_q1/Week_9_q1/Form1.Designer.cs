﻿namespace Week_9_q1
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.q1 = new System.Windows.Forms.TextBox();
            this.a1 = new System.Windows.Forms.TextBox();
            this.q5 = new System.Windows.Forms.TextBox();
            this.q4 = new System.Windows.Forms.TextBox();
            this.q3 = new System.Windows.Forms.TextBox();
            this.q2 = new System.Windows.Forms.TextBox();
            this.a3 = new System.Windows.Forms.TextBox();
            this.a4 = new System.Windows.Forms.TextBox();
            this.a5 = new System.Windows.Forms.TextBox();
            this.a2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Score = new System.Windows.Forms.TextBox();
            this.Set_q = new System.Windows.Forms.Button();
            this.Score_q = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // q1
            // 
            this.q1.Location = new System.Drawing.Point(139, 71);
            this.q1.Name = "q1";
            this.q1.ReadOnly = true;
            this.q1.Size = new System.Drawing.Size(105, 25);
            this.q1.TabIndex = 0;
            this.q1.TextChanged += new System.EventHandler(this.q1_TextChanged);
            // 
            // a1
            // 
            this.a1.Location = new System.Drawing.Point(325, 71);
            this.a1.Name = "a1";
            this.a1.Size = new System.Drawing.Size(105, 25);
            this.a1.TabIndex = 1;
            // 
            // q5
            // 
            this.q5.Location = new System.Drawing.Point(139, 325);
            this.q5.Name = "q5";
            this.q5.ReadOnly = true;
            this.q5.Size = new System.Drawing.Size(105, 25);
            this.q5.TabIndex = 2;
            this.q5.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // q4
            // 
            this.q4.Location = new System.Drawing.Point(139, 254);
            this.q4.Name = "q4";
            this.q4.ReadOnly = true;
            this.q4.Size = new System.Drawing.Size(105, 25);
            this.q4.TabIndex = 3;
            // 
            // q3
            // 
            this.q3.Location = new System.Drawing.Point(139, 192);
            this.q3.Name = "q3";
            this.q3.ReadOnly = true;
            this.q3.Size = new System.Drawing.Size(105, 25);
            this.q3.TabIndex = 4;
            this.q3.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // q2
            // 
            this.q2.Location = new System.Drawing.Point(139, 132);
            this.q2.Name = "q2";
            this.q2.ReadOnly = true;
            this.q2.Size = new System.Drawing.Size(105, 25);
            this.q2.TabIndex = 5;
            this.q2.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // a3
            // 
            this.a3.Location = new System.Drawing.Point(325, 192);
            this.a3.Name = "a3";
            this.a3.Size = new System.Drawing.Size(105, 25);
            this.a3.TabIndex = 6;
            // 
            // a4
            // 
            this.a4.Location = new System.Drawing.Point(325, 254);
            this.a4.Name = "a4";
            this.a4.Size = new System.Drawing.Size(105, 25);
            this.a4.TabIndex = 7;
            this.a4.TextChanged += new System.EventHandler(this.textBox8_TextChanged);
            // 
            // a5
            // 
            this.a5.Location = new System.Drawing.Point(325, 325);
            this.a5.Name = "a5";
            this.a5.Size = new System.Drawing.Size(105, 25);
            this.a5.TabIndex = 8;
            // 
            // a2
            // 
            this.a2.Location = new System.Drawing.Point(325, 132);
            this.a2.Name = "a2";
            this.a2.Size = new System.Drawing.Size(105, 25);
            this.a2.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(264, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(15, 15);
            this.label1.TabIndex = 10;
            this.label1.Text = "=";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(264, 142);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(15, 15);
            this.label2.TabIndex = 11;
            this.label2.Text = "=";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(264, 202);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(15, 15);
            this.label3.TabIndex = 12;
            this.label3.Text = "=";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(264, 264);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(15, 15);
            this.label4.TabIndex = 13;
            this.label4.Text = "=";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(264, 328);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(15, 15);
            this.label5.TabIndex = 14;
            this.label5.Text = "=";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(155, 385);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 15);
            this.label6.TabIndex = 15;
            this.label6.Text = "最终得分=";
            // 
            // Score
            // 
            this.Score.Location = new System.Drawing.Point(325, 375);
            this.Score.Name = "Score";
            this.Score.Size = new System.Drawing.Size(105, 25);
            this.Score.TabIndex = 16;
            // 
            // Set_q
            // 
            this.Set_q.Location = new System.Drawing.Point(159, 421);
            this.Set_q.Name = "Set_q";
            this.Set_q.Size = new System.Drawing.Size(58, 25);
            this.Set_q.TabIndex = 17;
            this.Set_q.Text = "出题";
            this.Set_q.UseVisualStyleBackColor = true;
            this.Set_q.Click += new System.EventHandler(this.Set_q_Click);
            // 
            // Score_q
            // 
            this.Score_q.Location = new System.Drawing.Point(334, 421);
            this.Score_q.Name = "Score_q";
            this.Score_q.Size = new System.Drawing.Size(58, 25);
            this.Score_q.TabIndex = 18;
            this.Score_q.Text = "提交";
            this.Score_q.UseVisualStyleBackColor = true;
            this.Score_q.Click += new System.EventHandler(this.Score_q_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 450);
            this.Controls.Add(this.Score_q);
            this.Controls.Add(this.Set_q);
            this.Controls.Add(this.Score);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.a2);
            this.Controls.Add(this.a5);
            this.Controls.Add(this.a4);
            this.Controls.Add(this.a3);
            this.Controls.Add(this.q2);
            this.Controls.Add(this.q3);
            this.Controls.Add(this.q4);
            this.Controls.Add(this.q5);
            this.Controls.Add(this.a1);
            this.Controls.Add(this.q1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox q1;
        private System.Windows.Forms.TextBox a1;
        private System.Windows.Forms.TextBox q5;
        private System.Windows.Forms.TextBox q4;
        private System.Windows.Forms.TextBox q3;
        private System.Windows.Forms.TextBox q2;
        private System.Windows.Forms.TextBox a3;
        private System.Windows.Forms.TextBox a4;
        private System.Windows.Forms.TextBox a5;
        private System.Windows.Forms.TextBox a2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Score;
        private System.Windows.Forms.Button Set_q;
        private System.Windows.Forms.Button Score_q;
    }
}

