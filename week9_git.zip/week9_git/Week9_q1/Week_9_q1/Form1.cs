﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_9_q1
{
    public partial class Form1 : Form
    {
        private int fin_score;
        private Color c_r = Color.Red;
        private Color c_g = Color.Green;
        private Color c_w = Color.White;
        private string[] opr = new string[] {"+","-","*","/" };
        private string[] s_q = new string[5];
        private int[] ans_all = new int[5];
        private Random r_n = new Random();
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void Set_q_Click(object sender, EventArgs e)
        {
            for(int i = 0; i < 5; i++)
            {
                fin_score = 0;
                a1.Clear();
                a2.Clear();
                a3.Clear();
                a4.Clear();
                a5.Clear();
                Score.Clear();
                int[] op_num =new int[] { r_n.Next(0, 4) ,r_n.Next(0,100),r_n.Next(0,100)};
                s_q[i] = Convert.ToString(op_num[1]) + opr[op_num[0]] + Convert.ToString(op_num[2]);
                if (op_num[0] == 0)
                {
                    ans_all[i] = op_num[1] + op_num[2];
                }
                else if (op_num[0] == 1)
                {
                    ans_all[i] = op_num[1] - op_num[2];
                }
                else if (op_num[0] == 2)
                {
                    ans_all[i] = op_num[1] * op_num[2];
                }
                else
                {
                    ans_all[i] =op_num[1] / op_num[2];
                }
                q1.Text = s_q[0];
                q2.Text = s_q[1];
                q3.Text = s_q[2];
                q4.Text = s_q[3];
                q5.Text = s_q[4];
            }
        }

        private void Score_q_Click(object sender, EventArgs e)
        {
            if (a1.Text == Convert.ToString(ans_all[0]))
            {
                a1.BackColor = c_g;
                fin_score += 20;
            }
            else
            {
                a1.BackColor = c_r;
            }
            if (a2.Text == Convert.ToString(ans_all[1]))
            {
                a2.BackColor = c_g;
                fin_score += 20;
            }
            else
            {
                a2.BackColor = c_r;
            }
            if (a3.Text == Convert.ToString(ans_all[2]))
            {
                a3.BackColor = c_g;
                fin_score += 20;
            }
            else
            {
                a3.BackColor = c_r;
            }
            if (a4.Text == Convert.ToString(ans_all[3]))
            {
                a4.BackColor = c_g;
                fin_score += 20;
            }
            else
            {
                a4.BackColor = c_r;
            }
            if (a5.Text == Convert.ToString(ans_all[4]))
            {
                a5.BackColor = c_g;
                fin_score += 20;
            }
            else
            {
                a5.BackColor = c_r;
            }
            Score.Text =Convert.ToString(fin_score);
        }

        private void q1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
