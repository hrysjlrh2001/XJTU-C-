﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week9_q3_fin_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(Add_subject.Text);
            Add_subject.Text = "";
        }

        private void listBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                Del_subject.Items.Add(listBox1.SelectedItem);

            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            for(int i = 0; i < Del_subject.Items.Count; i++)
            {
                listBox1.Items.Remove(Del_subject.Items[i]);
            }
            Del_subject.Items.Clear();
        }

        private void Add_combob_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Add(Add_combo.Text);
            Add_combo.Text = "";
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem != null)
            {
                del_combo.Text = comboBox1.SelectedItem.ToString();
            }
        }

        private void del_combob_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Remove(del_combo.Text);
            del_combo.Text = "";
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
