﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week_11_q2
{
    public partial class Form1 : Form
    {
        private Random a = new Random();
        private Color[] choose_color = new Color[4] { Color.Black,Color.Red,Color.Yellow,Color.Blue};
        private int col =0;
        public Form1()
        {
            InitializeComponent();
        }

        private void 画线ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Graphics ima_l = this.CreateGraphics();
            Pen d_l = new Pen(choose_color[col],3);
            ima_l.DrawLine(d_l, 10, 100, 20, 120);
        }

        private void 黑色ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            col = 0;
        }

        private void 红色ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            col = 1;
        }

        private void 蓝色ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            col = 2;
        }

        private void 黄色ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            col = 3;
        }

        private void 画图ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Graphics ima_c = this.CreateGraphics();
            Pen p_c = new Pen(choose_color[col],3);
            ima_c.DrawEllipse(p_c, 50, 90, 250, 290);
        }

        private void 画矩形ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Graphics ima_c = this.CreateGraphics();
            Pen p_c = new Pen(choose_color[col], 3);
            ima_c.DrawRectangle(p_c, 50, 90, 120, 170);
        }

        private void 删除ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Graphics ima_d = this.CreateGraphics();
            ima_d.Clear(Color.Gray);
        }

        private void 关于ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string uuu = "copyright: XJTU lrh";
            MessageBox.Show(uuu);
        }
    }
}
