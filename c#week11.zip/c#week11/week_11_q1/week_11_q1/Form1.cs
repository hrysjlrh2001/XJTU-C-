﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week_11_q1
{
    public partial class Form1 : Form
    {
        private int r = 10;
        private Point locat;
        private int prex;
        private int prey;
        private int i = 0;
        public Form1()
        {
            InitializeComponent();
            locat.X = -1;
            locat.Y = -1;
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void Form1_Click(object sender, EventArgs e)
        {
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            prex = locat.X;
            prey = locat.Y;
            Graphics ima_1 = this.CreateGraphics();
            locat = e.Location;
            Pen bla_line = new Pen(Color.Black);
            SolidBrush yrl_cel = new SolidBrush(Color.Yellow);
            ima_1.FillEllipse(yrl_cel, locat.X-r, locat.Y-r ,20, 20);
            if (i!=0)
            {
                ima_1.DrawLine(bla_line, prex , prey , locat.X , locat.Y);
            }
            i += 1;
        }
    }
}
