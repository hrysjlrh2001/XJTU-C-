﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week_11_q3
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }
        private int[] loca_tol_x = new int[225];
        private int[] loca_tol_y = new int[225];
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics ima = this.CreateGraphics();
            Pen dra_b = new Pen(Color.Black, 2);
            for(int i = 0; i < 15; i++)
            {
                ima.DrawLine(dra_b, 2, 2 + 20 * i, 282, 2 + 20 * i);
                ima.DrawLine(dra_b, 2 + 20 * i, 2, 2 + 20 * i,282);
            }
            int t = 0;
            for(int i = 0; i < 15; i++)
            {
                for(int j = 0; j < 15; j++)
                {
                    loca_tol_x[t] = 2 + 20 * i;
                    loca_tol_y[t] = 2 + 20 * j;
                    t = t + 1;
                }
            }
        }
        private SolidBrush bl_bru = new SolidBrush(Color.Black);
        private SolidBrush wh_bru = new SolidBrush(Color.White);
        private int[] judge(int x,int y)
        {
            int[] fin =new int[] { 0, 0 };
            for(int i = 0; i < loca_tol_x.Length; i++)
            {
                if(x<loca_tol_x[i]+8 && x > loca_tol_x[i] - 8)
                {
                    if(y<loca_tol_y[i]+8 && y > loca_tol_y[i] - 8)
                    {
                        fin[0] = loca_tol_x[i];
                        fin[1] = loca_tol_y[i];
                    }
                }
            }
            return fin;
        }
        private void draw_card(int x,int y,int times,Graphics ima)
        {
            if (judge(x, y)[0]!=0)
            {
                if (times % 2 == 0)
                {
                    ima.FillEllipse(wh_bru, judge(x, y)[0]-6, judge(x, y)[1]-6, 12,12);
                }
                else
                {
                    ima.FillEllipse(bl_bru, judge(x, y)[0]-6, judge(x, y)[1]-6,12, 12);
                }
            }
        }
        private int times = 0;
        private void Form1_Click(object sender, EventArgs e)
        {
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            Graphics ima = this.CreateGraphics();
            times += 1;
            draw_card(e.Location.X, e.Location.Y, times, ima);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
