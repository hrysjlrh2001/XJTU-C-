﻿namespace Week12_q3
{
    partial class write_in_c
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.diaplay_stu = new System.Windows.Forms.Button();
            this.Name_stu = new System.Windows.Forms.TextBox();
            this.Name_grade = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "姓名";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(190, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "成绩";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "学生成绩";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(200, 291);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(83, 28);
            this.button1.TabIndex = 5;
            this.button1.Text = "写入";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(433, 291);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(295, 79);
            this.textBox2.TabIndex = 7;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // diaplay_stu
            // 
            this.diaplay_stu.Location = new System.Drawing.Point(544, 393);
            this.diaplay_stu.Name = "diaplay_stu";
            this.diaplay_stu.Size = new System.Drawing.Size(83, 28);
            this.diaplay_stu.TabIndex = 8;
            this.diaplay_stu.Text = "显示";
            this.diaplay_stu.UseVisualStyleBackColor = true;
            this.diaplay_stu.Click += new System.EventHandler(this.diaplay_stu_Click);
            // 
            // Name_stu
            // 
            this.Name_stu.Location = new System.Drawing.Point(72, 92);
            this.Name_stu.Name = "Name_stu";
            this.Name_stu.Size = new System.Drawing.Size(100, 25);
            this.Name_stu.TabIndex = 9;
            // 
            // Name_grade
            // 
            this.Name_grade.Location = new System.Drawing.Point(265, 93);
            this.Name_grade.Name = "Name_grade";
            this.Name_grade.Size = new System.Drawing.Size(100, 25);
            this.Name_grade.TabIndex = 10;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 15;
            this.listBox1.Location = new System.Drawing.Point(433, 75);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(295, 154);
            this.listBox1.TabIndex = 11;
            // 
            // write_in_c
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.Name_grade);
            this.Controls.Add(this.Name_stu);
            this.Controls.Add(this.diaplay_stu);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "write_in_c";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button diaplay_stu;
        private System.Windows.Forms.TextBox Name_stu;
        private System.Windows.Forms.TextBox Name_grade;
        private System.Windows.Forms.ListBox listBox1;
    }
}

