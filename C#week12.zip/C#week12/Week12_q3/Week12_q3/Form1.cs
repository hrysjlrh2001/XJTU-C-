﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Week12_q3
{
    public partial class write_in_c : Form
    {
        public write_in_c()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void diaplay_stu_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(Name_stu.Text+" "+Name_grade.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool exist = System.IO.Directory.Exists("C:\\ShareFile");
            if(exist == false)
            {
                Directory.CreateDirectory("C:\\ShareFile");
            }
            SaveFileDialog save_txt = new SaveFileDialog();
            save_txt.Filter="txt(*.txt)|*.txt";
            if (save_txt.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    StreamWriter swrite = new StreamWriter(save_txt.FileName);
                    string content = "";
                    double times = 0;
                    double total_grade = 0;
                    foreach(object o in listBox1.Items)
                    {
                        content += o.ToString();
                        content += "\r\n";
                        times += 1;
                        total_grade +=Convert.ToInt32(o.ToString().Split(' ')[1]);
                    }
                    string text_box = "";
                    text_box += save_txt.FileName + "\r\n";
                    text_box += DateTime.Now.ToString() + "\r\n";
                    text_box += "学生平均分:" + total_grade / times;
                    textBox2.Text = text_box;
                    swrite.Write(content);
                    swrite.Close();
                    content = "";
                }
                catch
                {
                    MessageBox.Show("写入错误");
                }
            }
        }
    }
}
