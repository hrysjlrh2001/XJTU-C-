﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week12_q4
{
    public partial class Form2 : Form
    {
        public string Cont
        {
            get
            {
                return textBox1.Text;
            }
        }
        public string Cont_2;
        public Form2(string content)
        {
            InitializeComponent();
            textBox1.Text = content;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Cont_2 = textBox1.Text;
        }
    }
}
