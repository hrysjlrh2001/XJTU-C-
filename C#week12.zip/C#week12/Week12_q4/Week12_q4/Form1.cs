﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Week12_q4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Form2 form_2 = new Form2("");
        Form2 form2 = new Form2("");
        private string content;
        private void 打开ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Point p1 = new Point();
            p1.X = 0;
            p1.Y = 40;
            OpenFileDialog open_file = new OpenFileDialog();
            open_file.Filter = "txt(*.txt)|*.txt|word|*.doc,*.docx";
            if (open_file.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    StreamReader sread = new StreamReader(open_file.FileName);
                    string content = sread.ReadToEnd();
                    form2.MdiParent = this;
                    form2.textBox1.Text = content;
                    form2.Location=p1;
                    form2.Show();
                    sread.Close();
                }
                catch
                {
                    MessageBox.Show("Read Error!");
                }
            }
        }

        private void 保存ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog save_file = new SaveFileDialog();
            save_file.Filter = "txt|*.txt|word|*.doc,*.docx";
            if (save_file.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    StreamWriter swrite = new StreamWriter(save_file.FileName);
                    swrite.Write(form_2.Cont);
                    swrite.Close();
                }
                catch
                {
                    MessageBox.Show("Write Error!");
                }
            }
        }

        private void 新建ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            form_2.MdiParent = this;
            form_2.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            form_2.Close();
            form2.Close();
        }

        private void 水平ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Point p1 = new Point();
            p1.X = 10;
            p1.Y = 10;
            Point p2 = new Point();
            p2.X = p1.X + form_2.Size.Width;
            p2.Y = p1.Y;
            form_2.Location = p1;
            form2.Location = p2;
        }

        private void 垂直ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            form_2.Height = 200;
            form2.Height = 200;
            Point p1 = new Point();
            p1.X = 10;
            p1.Y = 10;
            Point p2 = new Point();
            p2.X = p1.X ;
            p2.Y = p1.Y + form_2.Size.Height;
            form_2.Location = p1;
            form2.Location = p2;
        }
    }
}
