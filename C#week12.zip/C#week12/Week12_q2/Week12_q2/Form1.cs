﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week12_q2
{
    public partial class Form1 : Form
    {
        public string uname
        {
            get
            {
                return username.Text;
            }
        }
        private string paw = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string una = username.Text;
            if(una.Length==0)
            {
                MessageBox.Show("用户名不能为空");
            }
            else if (paw.Length == 0)
            {
                MessageBox.Show("密码不能为空");
            }
            else
            {
                Form2 f = new Form2(username.Text);
                f.Show();
            }
        }

        private void password_TextChanged(object sender, EventArgs e)
        {
            paw += password.Text[password.Text.Length - 1];
            string word = "";
            for(int i = 0; i < password.Text.Length; i++)
            {
                word += "*";
            }
            password.Text = word;
        }
    }
}
