﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Week12_q1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Write_Click(object sender, EventArgs e)
        {
            SaveFileDialog savefile = new SaveFileDialog();
            savefile.Filter = "txt(*.txt)|*.txt";
            if (savefile.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    StreamWriter swrite = new StreamWriter(savefile.FileName);
                    string content = textBox1.Text;
                    swrite.Write(content);
                    swrite.Close();
                }
                catch
                {
                    MessageBox.Show("Write Error");
                }
            }

        }

        private void Read_Click(object sender, EventArgs e)
        {
            OpenFileDialog oread = new OpenFileDialog();
            oread.Filter = "txt(*.txt)|*.txt";
            if (oread.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    StreamReader sread = new StreamReader(oread.FileName);
                    string content_r = sread.ReadToEnd();
                    textBox1.Text = content_r;
                    sread.Close();
                }
                catch
                {
                    MessageBox.Show("Write error.");
                }
            }
        }
    }
}
